const videoElement = document.getElementsByClassName('input_video')[0];
const canvasElement = document.getElementsByClassName('output_canvas')[0];
const canvasCtx = canvasElement.getContext('2d');

class Point {
  constructor(x, y) {
      this.x = x;
      this.y = y;
  }

  static displayName = "Point";
  static distance(a, b) {
      const dx = a.x - b.x;
      const dy = a.y - b.y;
      return Math.hypot(dx, dy);
  }

  static mean(a, b) {
      const meanx = (a.x + b.x) / 2
      const meany = (a.y + b.y) / 2
      return new Point(meanx, meany)
  }
}

//The Matter.js part
var Engine = Matter.Engine,
    Render = Matter.Render,
    World = Matter.World,
    Bodies = Matter.Bodies,
    Constraint = Matter.Constraint;


// create an engine
var engine = Engine.create();
var render = Render.create({
  element: document.body,
  engine: engine
});


// create two boxes and a ground
var boxA = Bodies.rectangle(150, 0, 5, 5, { isStatic: true });
var boxB = Bodies.rectangle(450, 100, 150, 400);


var options = {
  bodyA: boxA,
  bodyB: boxB,
  pointA: {
    x: 0,
    y: -100
  }
}
var PunchBag = Matter.Constraint.create(options);
World.add(engine.world, [boxA, boxB,  PunchBag]);
var rightHand = Bodies.rectangle(300, 300, 50, 50);
var lefttHand = Bodies.rectangle(300, 300, 50, 50);
var rightfoot = Bodies.rectangle(300, 300, 50, 50);
var lefttfoot = Bodies.rectangle(300, 300, 50, 50);
World.add(engine.world, [rightHand,lefttHand]);



// The graphic of punch 
const CVS_WIDTH = canvasElement.width;
const CVS_HEIGHT = canvasElement.height;
const FLAG_DRAW_POSE = true;
const FLAG_DRAW_HANDS = false;
const FLAG_SMOOTH = true;
const boxingImg = new Image(800, 1250);
const boxingImg2 = new Image(800, 1250);
boxingImg.src = "images/boxing.png";
boxingImg2.src = "images/boxing2.png";

const bootImg = new Image(800, 1250);
const bootImg2 = new Image(800, 1250);
bootImg.src = "images/boot.png";
bootImg2.src = "images/boot2.png";

function rotateAndPaintImage ( canvasCtx, image, angleInRad, posX, posY, dx, dy, dWidth, dHeight) {
  canvasCtx.translate(posX, posY);
  canvasCtx.rotate( angleInRad );
  canvasCtx.drawImage( image, dx, dy, dWidth, dHeight);
  canvasCtx.rotate( -angleInRad );
  canvasCtx.setTransform(1, 0, 0, 1, 0, 0);
}





function onResults(results) {
  canvasCtx.save();
  canvasCtx.clearRect(0, 0,  CVS_WIDTH, CVS_HEIGHT);
  canvasCtx.drawImage(
      results.image, 0, 0,  CVS_WIDTH, CVS_HEIGHT);
  drawConnectors(canvasCtx, results.poseLandmarks, POSE_CONNECTIONS,
                 {color: '#00FF00', lineWidth: 1});
  drawLandmarks(canvasCtx, results.poseLandmarks,
                {color: '#FF0000', lineWidth: 1});

  //hand rising detector
  var angleRadians1 = -Math.atan2(results.poseLandmarks[15].y - results.poseLandmarks[13].y, results.poseLandmarks[15].x - results.poseLandmarks[13].x) * 180 / Math.PI;
  var angleRadians2 = -Math.atan2(results.poseLandmarks[16].y - results.poseLandmarks[14].y, results.poseLandmarks[16].x - results.poseLandmarks[14].x) * 180 / Math.PI;
  if ((60<=angleRadians2 && angleRadians2<=130) || (60<=angleRadians1 && angleRadians1<=130)  ){
    canvasCtx.strokeText("handRising", 10, 240)
  }

  // The punch picture
  const lHandPos = new Point(results.poseLandmarks[15].x*CVS_WIDTH, results.poseLandmarks[15].y*CVS_HEIGHT);
  const rHandPos = new Point(results.poseLandmarks[16].x*CVS_WIDTH, results.poseLandmarks[16].y*CVS_HEIGHT);
  const lIndexPos = new Point(results.poseLandmarks[19].x*CVS_WIDTH, results.poseLandmarks[19].y*CVS_HEIGHT);
  const rIndexPos = new Point(results.poseLandmarks[20].x*CVS_WIDTH, results.poseLandmarks[20].y*CVS_HEIGHT);
  const lElbowPos = new Point(results.poseLandmarks[13].x*CVS_WIDTH, results.poseLandmarks[13].y*CVS_HEIGHT);
  const rElbowPos = new Point(results.poseLandmarks[14].x*CVS_WIDTH, results.poseLandmarks[14].y*CVS_HEIGHT);
  const imgH = Point.distance(rHandPos, rIndexPos) * 2;
  const imgW = imgH * (boxingImg.width / boxingImg.height);
  const imgAngle = Math.atan2(rHandPos.y - rElbowPos.y, rHandPos.x - rElbowPos.x) + Math.PI/2; // angle in radians
  var imgH2 = Point.distance(lHandPos, lIndexPos) * 2;
  var imgW2 = imgH2 * (boxingImg.width / boxingImg.height);
  const imgAngle2 = Math.atan2(lHandPos.y - lElbowPos.y, lHandPos.x - lElbowPos.x) + Math.PI/2;
  // The kick picture
  const lfootPos = new Point(results.poseLandmarks[27].x*CVS_WIDTH, results.poseLandmarks[27].y*CVS_HEIGHT);
  const rfootPos = new Point(results.poseLandmarks[28].x*CVS_WIDTH, results.poseLandmarks[28].y*CVS_HEIGHT);
  const lfIndexPos = new Point(results.poseLandmarks[29].x*CVS_WIDTH, results.poseLandmarks[29].y*CVS_HEIGHT);
  const rfIndexPos = new Point(results.poseLandmarks[30].x*CVS_WIDTH, results.poseLandmarks[30].y*CVS_HEIGHT);
  const llegPos = new Point(results.poseLandmarks[23].x*CVS_WIDTH, results.poseLandmarks[23].y*CVS_HEIGHT);
  const rlegPos = new Point(results.poseLandmarks[24].x*CVS_WIDTH, results.poseLandmarks[24].y*CVS_HEIGHT);
  const imgH3 = Point.distance(rfootPos, rfIndexPos) * 5;
  const imgW3 = imgH3 * (bootImg.width / bootImg.height)*1.5;
  const imgAngle3 = Math.atan2(rfootPos.y - rlegPos.y, rfootPos.x - rlegPos.x) + Math.PI/2; // angle in radians
  const imgH4 =  Point.distance(lfootPos, lfIndexPos) * 5;
  const imgW4 = imgH4 * (bootImg.width / bootImg.height)*1.5;
  const imgAngle4 = Math.atan2(lfootPos.y - llegPos.y, lfootPos.x - llegPos.x) + Math.PI/2; // angle in radians


  rotateAndPaintImage(canvasCtx, boxingImg2, imgAngle2, lHandPos.x, lHandPos.y, -imgW2/2, -imgH2, imgW2, imgH2);
  rotateAndPaintImage(canvasCtx, boxingImg, imgAngle, rHandPos.x, rHandPos.y, -imgW/2, -imgH, imgW, imgH);
  rotateAndPaintImage(canvasCtx, bootImg2, imgAngle3, lfootPos.x, lfootPos.y, -imgW3/2, -imgH3, imgW3, imgH3);
  rotateAndPaintImage(canvasCtx, bootImg, imgAngle4, rfootPos.x, rfootPos.y, -imgW4/2, -imgH4, imgW4, imgH4);
  console.log(imgAngle3);
canvasCtx.restore();
}


function Rendering() {
  var bodies = Matter.Composite.allBodies(engine.world);
  canvasCtx.fillStyle = 'red';
  canvasCtx.beginPath();
  for (var i = bodies.length-3; i < bodies.length-2; i += 1) {
      var vertices = bodies[i].vertices;
      canvasCtx.moveTo(vertices[0].x, vertices[0].y);
      for (var j = 1; j < vertices.length; j += 1) {
        canvasCtx.lineTo(vertices[j].x, vertices[j].y);
      }
      canvasCtx.fillStyle = 'red';
      canvasCtx.lineTo(vertices[0].x, vertices[0].y);
  }
  canvasCtx.lineWidth = 1;
  canvasCtx.strokeStyle = '#ff0000';
  canvasCtx.stroke();
  canvasCtx.fill()
}




const pose = new Pose({locateFile: (file) => {
  return `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`;
}});
pose.setOptions({
  upperBodyOnly: false,
  smoothLandmarks: true,
  minDetectionConfidence: 0.4,
  minTrackingConfidence: 0.4,
  selfieMode: true
});




pose.onResults(results=>{
  onResults(results);
  Matter.Body.setPosition(rightHand, {x: results.poseLandmarks[19].x*1280, y: results.poseLandmarks[19].y*720});
  Matter.Body.setPosition(lefttHand, {x: results.poseLandmarks[20].x*1280, y: results.poseLandmarks[20].y*720});
  Matter.Body.setPosition(rightfoot, {x: results.poseLandmarks[30].x*1280, y: results.poseLandmarks[30].y*720});
  Matter.Body.setPosition(lefttfoot, {x: results.poseLandmarks[31].x*1280, y: results.poseLandmarks[31].y*720});
  Rendering(); 
});


const camera = new Camera(videoElement, {
  onFrame: async () => {
    await pose.send({image: videoElement});
  },
  width: 1280,
  height: 720,
  depth: 30,
});

camera.start();
Engine.run(engine);