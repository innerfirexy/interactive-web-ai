const videoElement = document.getElementsByClassName("input_video")[0];
const canvasElement = document.getElementsByClassName("output_canvas")[0];
const canvasCtx = canvasElement.getContext("2d");
var countEffect = 'on';
var visualEffect = "on";
var obj = "punchBag";
var picture = "show";
var speed = "show";
var ponchCount = "show";
var speedEffect = 'on';
var pathS = [];
var speed = 0;
var kickCount = 0;
var feetDist = 0;
var pathf = [];
var elem = document.getElementById("myBar");
document.getElementById("bolloon").onclick = function changeMode() {
  obj = "bolloon";
};
document.getElementById("punchBag").onclick = function changeMode() {
  obj = "punchBag";
};
document.getElementById("showImage").onclick = function changeMode() {
  if (visualEffect == "on") {
    visualEffect = "off";
  } else if (visualEffect == "off") {
    visualEffect = "on";
  }
};

document.getElementById("countEffect").onclick = function changeMode() {
  if (countEffect == "on") {
    countEffect = "off";
  } else if (countEffect == "off") {
    countEffect = "on";
  }
};

document.getElementById("clearCount").onclick = function changeMode() {
  path = [];
  pathf = [];

};

document.getElementById("speedEffect").onclick = function changeMode() {
  if (speedEffect == "on") {
    speedEffect = "off";
  } else if (speedEffect == "off") {
    speedEffect = "on";
  }
};

//The array used for counting
var path = [];
//The counting
var p = 0;

class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  static displayName = "Point";
  static distance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    return Math.hypot(dx, dy);
  }

  static mean(a, b) {
    const meanx = (a.x + b.x) / 2;
    const meany = (a.y + b.y) / 2;
    return new Point(meanx, meany);
  }
}

//The Matter.js part
var Engine = Matter.Engine,
  Render = Matter.Render,
  World = Matter.World,
  Bodies = Matter.Bodies,
  Constraint = Matter.Constraint;

// create an engine
var engine = Engine.create({
  constraintIterations: 5,
  positionIterations: 10,
  timing: {
    timestamp: 0,
    timeScale: 1.2,
  },
});
var render = Render.create({
  element: document.body,
  engine: engine,
});

// create two boxes and a ground
var boxA = Bodies.rectangle(150, 0, 5, 5, { isStatic: true });
//Here is the item you need to change for the punching bag. You can change it according to the matter.js document. Change it to another item.
if (obj == "punchBag") {
  var boxB = Bodies.rectangle(450, 100, 150, 500);
} else if ((obj = "bolloon")) {
  var boxB = Bodies.rectangle(450, 100, 150, 150);
}

var options = {
  bodyA: boxA,
  bodyB: boxB,
  pointA: {
    x: 0,
    y: -50,
  },
};
var PunchBag = Matter.Constraint.create(options);
World.add(engine.world, [boxA, boxB, PunchBag]);
var rightHand = Bodies.rectangle(300, 300, 50, 50);
var lefttHand = Bodies.rectangle(300, 300, 50, 50);
var rightfoot = Bodies.rectangle(300, 300, 50, 50);
var lefttfoot = Bodies.rectangle(300, 300, 50, 50);
World.add(engine.world, [rightHand, lefttHand, rightfoot, lefttfoot]);

// The graphic of punch
const CVS_WIDTH = canvasElement.width;
const CVS_HEIGHT = canvasElement.height;
const FLAG_DRAW_POSE = true;
const FLAG_DRAW_HANDS = false;
const FLAG_SMOOTH = true;
const boxingImg = new Image(800, 1250);
const boxingImg2 = new Image(800, 1250);
boxingImg.src = "images/boxing.png";
boxingImg2.src = "images/boxing2.png";

const bootImg = new Image(800, 1250);
const bootImg2 = new Image(800, 1250);
bootImg.src = "images/boot.png";
bootImg2.src = "images/boot2.png";

const punchbag = new Image(200, 500);
punchbag.src = "images/punchbag.png";
const balloon = new Image(100, 100);
balloon.src = "images/balloon.png";
function showSkeleton(canvasCtx, poseLandmarks){
  canvasCtx.beginPath();
  canvasCtx.moveTo(poseLandmarks[12].x*CVS_WIDTH, poseLandmarks[12].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[11].x*CVS_WIDTH, poseLandmarks[11].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[23].x*CVS_WIDTH, poseLandmarks[23].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[24].x*CVS_WIDTH, poseLandmarks[24].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[12].x*CVS_WIDTH, poseLandmarks[12].y*CVS_HEIGHT);
  canvasCtx.moveTo(poseLandmarks[12].x*CVS_WIDTH, poseLandmarks[12].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[14].x*CVS_WIDTH, poseLandmarks[14].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[16].x*CVS_WIDTH, poseLandmarks[16].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[18].x*CVS_WIDTH, poseLandmarks[18].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[20].x*CVS_WIDTH, poseLandmarks[20].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[16].x*CVS_WIDTH, poseLandmarks[16].y*CVS_HEIGHT);
  canvasCtx.moveTo(poseLandmarks[11].x*CVS_WIDTH, poseLandmarks[11].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[13].x*CVS_WIDTH, poseLandmarks[13].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[15].x*CVS_WIDTH, poseLandmarks[15].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[17].x*CVS_WIDTH, poseLandmarks[17].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[19].x*CVS_WIDTH, poseLandmarks[19].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[15].x*CVS_WIDTH, poseLandmarks[15].y*CVS_HEIGHT);
  canvasCtx.moveTo(poseLandmarks[24].x*CVS_WIDTH, poseLandmarks[24].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[26].x*CVS_WIDTH, poseLandmarks[26].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[28].x*CVS_WIDTH, poseLandmarks[28].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[32].x*CVS_WIDTH, poseLandmarks[32].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[30].x*CVS_WIDTH, poseLandmarks[30].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[28].x*CVS_WIDTH, poseLandmarks[28].y*CVS_HEIGHT);
  canvasCtx.moveTo(poseLandmarks[23].x*CVS_WIDTH, poseLandmarks[23].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[25].x*CVS_WIDTH, poseLandmarks[25].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[27].x*CVS_WIDTH, poseLandmarks[27].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[31].x*CVS_WIDTH, poseLandmarks[31].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[29].x*CVS_WIDTH, poseLandmarks[29].y*CVS_HEIGHT);
  canvasCtx.lineTo(poseLandmarks[27].x*CVS_WIDTH, poseLandmarks[27].y*CVS_HEIGHT);
  canvasCtx.strokeStyle = '#00FF00';
  canvasCtx.stroke();
  canvasCtx.restore;

}

function rotateAndPaintImage(
  canvasCtx,
  image,
  angleInRad,
  posX,
  posY,
  dx,
  dy,
  dWidth,
  dHeight
) {
  canvasCtx.translate(posX, posY);
  canvasCtx.rotate(angleInRad);
  canvasCtx.drawImage(image, dx, dy, dWidth, dHeight);
  canvasCtx.rotate(-angleInRad);
  canvasCtx.setTransform(1, 0, 0, 1, 0, 0);
}


function onResults(results) {
  canvasCtx.save();
  canvasCtx.clearRect(0, 0, CVS_WIDTH, CVS_HEIGHT);
  canvasCtx.drawImage(results.image, 0, 0, CVS_WIDTH, CVS_HEIGHT);
  //drawConnectors(canvasCtx, results.poseLandmarks, POSE_CONNECTIONS, {color: '#00FF00', lineWidth: 1});
  //drawLandmarks(canvasCtx, results.poseLandmarks, {color: '#FF0000', lineWidth: 1});
  showSkeleton(canvasCtx, results.poseLandmarks);
  //hand rising detector
  var angleRadians1 =
    (-Math.atan2(
      results.poseLandmarks[15].y - results.poseLandmarks[13].y,
      results.poseLandmarks[15].x - results.poseLandmarks[13].x
    ) *
      180) /
    Math.PI;
  var angleRadians2 =
    (-Math.atan2(
      results.poseLandmarks[16].y - results.poseLandmarks[14].y,
      results.poseLandmarks[16].x - results.poseLandmarks[14].x
    ) *
      180) /
    Math.PI;
  if (
    (60 <= angleRadians2 && angleRadians2 <= 130) ||
    (60 <= angleRadians1 && angleRadians1 <= 130)
  ) {
    canvasCtx.strokeText("handRising", 10, 240);
  }

  // all datapoint needed
  const lHandPos = new Point(
    results.poseLandmarks[15].x * CVS_WIDTH,
    results.poseLandmarks[15].y * CVS_HEIGHT
  );
  const rHandPos = new Point(
    results.poseLandmarks[16].x * CVS_WIDTH,
    results.poseLandmarks[16].y * CVS_HEIGHT
  );
  const lIndexPos = new Point(
    results.poseLandmarks[19].x * CVS_WIDTH,
    results.poseLandmarks[19].y * CVS_HEIGHT
  );
  const rIndexPos = new Point(
    results.poseLandmarks[20].x * CVS_WIDTH,
    results.poseLandmarks[20].y * CVS_HEIGHT
  );
  const lElbowPos = new Point(
    results.poseLandmarks[13].x * CVS_WIDTH,
    results.poseLandmarks[13].y * CVS_HEIGHT
  );
  const rElbowPos = new Point(
    results.poseLandmarks[14].x * CVS_WIDTH,
    results.poseLandmarks[14].y * CVS_HEIGHT
  );
  const imgH = Point.distance(rHandPos, rIndexPos) * 2;
  const imgW = imgH * (boxingImg.width / boxingImg.height);
  const imgAngle =
    Math.atan2(rHandPos.y - rElbowPos.y, rHandPos.x - rElbowPos.x) +
    Math.PI / 2; // angle in radians
  var imgH2 = Point.distance(lHandPos, lIndexPos) * 2;
  var imgW2 = imgH2 * (boxingImg.width / boxingImg.height);
  const imgAngle2 =
    Math.atan2(lHandPos.y - lElbowPos.y, lHandPos.x - lElbowPos.x) +
    Math.PI / 2;
  // The kick picture
  const lfootPos = new Point(
    results.poseLandmarks[27].x * CVS_WIDTH,
    results.poseLandmarks[27].y * CVS_HEIGHT
  );
  const rfootPos = new Point(
    results.poseLandmarks[28].x * CVS_WIDTH,
    results.poseLandmarks[28].y * CVS_HEIGHT
  );
  const lfIndexPos = new Point(
    results.poseLandmarks[29].x * CVS_WIDTH,
    results.poseLandmarks[29].y * CVS_HEIGHT
  );
  const rfIndexPos = new Point(
    results.poseLandmarks[30].x * CVS_WIDTH,
    results.poseLandmarks[30].y * CVS_HEIGHT
  );
  const llegPos = new Point(
    results.poseLandmarks[25].x * CVS_WIDTH,
    results.poseLandmarks[25].y * CVS_HEIGHT
  );
  const rlegPos = new Point(
    results.poseLandmarks[26].x * CVS_WIDTH,
    results.poseLandmarks[26].y * CVS_HEIGHT
  );
  const imgH3 = Point.distance(rfootPos, rfIndexPos) * 5;
  const imgW3 = imgH3 * (bootImg.width / bootImg.height) * 1.5;
  const imgAngle3 =
    Math.atan2(rfootPos.y - rlegPos.y, rfootPos.x - rlegPos.x) + Math.PI / 2; // angle in radians
  const imgH4 = Point.distance(lfootPos, lfIndexPos) * 5;
  const imgW4 = imgH4 * (bootImg.width / bootImg.height) * 1.5;
  const imgAngle4 =
    Math.atan2(lfootPos.y - llegPos.y, lfootPos.x - llegPos.x) + Math.PI / 2; // angle in radians

  const rfoot_tip = new Point(
    results.poseLandmarks[32].x * CVS_WIDTH,
    results.poseLandmarks[32].y * CVS_HEIGHT
  );
  const lfoot_tip = new Point(
    results.poseLandmarks[31].x * CVS_WIDTH,
    results.poseLandmarks[31].y * CVS_HEIGHT
  );

  if (visualEffect == "on") {
    rotateAndPaintImage(
      canvasCtx,
      boxingImg2,
      imgAngle2,
      lHandPos.x,
      lHandPos.y,
      -imgW2 / 2,
      -imgH2,
      imgW2,
      imgH2
    );
    rotateAndPaintImage(
      canvasCtx,
      boxingImg,
      imgAngle,
      rHandPos.x,
      rHandPos.y,
      -imgW / 2,
      -imgH,
      imgW,
      imgH
    );

    if (lfoot_tip.x > lfootPos.x) {
      rotateAndPaintImage(
        canvasCtx,
        bootImg2,
        imgAngle4,
        lfootPos.x,
        lfootPos.y,
        -imgW3 / 2 - 20,
        -imgH3,
        imgW3,
        imgH3
      );
    } else {
      rotateAndPaintImage(
        canvasCtx,
        bootImg,
        imgAngle4,
        lfootPos.x,
        lfootPos.y,
        -imgW3 / 2 - 20,
        -imgH3,
        imgW3,
        imgH3
      );
    }

    if (rfoot_tip.x < rfootPos.x) {
      rotateAndPaintImage(
        canvasCtx,
        bootImg,
        imgAngle3,
        rfootPos.x,
        rfootPos.y,
        -imgW4 / 2 + 20,
        -imgH4,
        imgW4,
        imgH4
      );
    } else {
      rotateAndPaintImage(
        canvasCtx,
        bootImg2,
        imgAngle3,
        rfootPos.x,
        rfootPos.y,
        -imgW4 / 2 + 20,
        -imgH4,
        imgW4,
        imgH4
      );
    }
  }
  //the function for kick count
  canvasCtx.font = "20px Verdana";
  feetDist = Math.abs(rfootPos.y - lfootPos.y);
  feetDist = Math.trunc(feetDist / 10);

  pathf.push(feetDist);
  kickCount = getLocalMaxima(pathf);
  

  // The function for punching count
  path.push(Math.trunc(rHandPos.x / 100));
  
  var top = getLocalMinima(path);

  if(countEffect == 'on'){
  canvasCtx.fillText('kick', 700, 190);
  canvasCtx.fillText(kickCount.peaks.length, 790, 190);
  canvasCtx.fillText('punch', 700, 100);
  canvasCtx.fillText(top.peaks.length, 790, 100);
  }else{
    pathf = [];
    path = [];
  }



  pathS.push(Math.trunc(rHandPos.x / 10));


  if (pathS.length > 5) {
    speed = Math.abs(pathS[pathS.length - 1] - pathS[pathS.length - 6]);
  }

  speed = (speed / 50) * 100;
  if (speed < 15) {
    speed = 0;
  }
  if(speedEffect == 'on'){
     var id = setInterval(frame, 500);
  function frame() {
    elem.style.width = speed + "%";
  }
  canvasCtx.fillText('Speed', 700, 160);
  canvasCtx.fillText(Math.trunc(speed), 790, 160); 
  }


  canvasCtx.restore();
}
function getLocalMinima(array) {
  return array.reduce(
    function (r, v, i, a) {
      var j = i;
      while (v === a[++j]);
      if (a[i - 1] > v && (a[i + 1] > v || (a[i + 1] === v && a[j] > v))) {
        r.pos.push(i);
        if (v < 4) {
          r.peaks.push(v);
        }
      }
      return r;
    },
    { pos: [], peaks: [] }
  );
  // The function for puncthing is above
}

function getLocalMaxima(array) {
  return array.reduce(
    function (r, v, i, a) {
      var j = i;
      while (v === a[++j]);
      if (a[i - 1] < v && (a[i + 1] < v || (a[i + 1] === v && a[j] < v))) {
        r.pos.push(i);

        if (v > 5) {
          r.peaks.push(v);
        }
      }
      return r;
    },
    { pos: [], peaks: [] }
  );
  // The function for puncthing is above
}

function Rendering() {
  var bodies = Matter.Composite.allBodies(engine.world);
  canvasCtx.fillStyle = "red";
  canvasCtx.beginPath();
  for (var i = 0; i < bodies.length; i += 1) {
    var vertices = bodies[i].vertices;
    canvasCtx.moveTo(vertices[0].x, vertices[0].y);
    for (var j = 1; j < vertices.length; j += 1) {
      canvasCtx.lineTo(vertices[j].x, vertices[j].y);
    }
    //canvasCtx.fillStyle = 'red';
    canvasCtx.lineTo(vertices[0].x, vertices[0].y);
  }
  canvasCtx.lineWidth = 1;
  canvasCtx.strokeStyle = "#ff0000";
  canvasCtx.stroke();
  //canvasCtx.fill()
}

const pose = new Pose({
  locateFile: (file) => {
    return `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`;
  },
});
pose.setOptions({
  upperBodyOnly: false,
  smoothLandmarks: true,
  minDetectionConfidence: 0.4,
  minTrackingConfidence: 0.4,
  selfieMode: true,
});

pose.onResults((results) => {
  onResults(results);
  Matter.Body.setPosition(rightHand, {
    x: results.poseLandmarks[19].x * 1280,
    y: results.poseLandmarks[19].y * 720,
  });
  Matter.Body.setPosition(lefttHand, {
    x: results.poseLandmarks[20].x * 1280,
    y: results.poseLandmarks[20].y * 720,
  });
  Matter.Body.setPosition(rightfoot, {
    x: results.poseLandmarks[30].x * 1280,
    y: results.poseLandmarks[30].y * 720,
  });
  Matter.Body.setPosition(lefttfoot, {
    x: results.poseLandmarks[31].x * 1280,
    y: results.poseLandmarks[31].y * 720,
  });
  var bodies = Matter.Composite.allBodies(engine.world);
  var vertices = bodies[1].vertices;
  const imgAngle0 =
    Math.atan2(vertices[3].y - vertices[1].y, vertices[3].x - vertices[1].x) +
    Math.PI / 2; // angle in radians

  if (visualEffect == "on") {
    if (obj == "punchBag") {
      rotateAndPaintImage(
        canvasCtx,
        punchbag,
        imgAngle0 - 0.35,
        (vertices[0].x + vertices[1].x) / 2,
        vertices[0].y,
        -290,
        -600,
        600,
        700
      );
    } else if (obj == "bolloon") {
      rotateAndPaintImage(
        canvasCtx,
        balloon,
        imgAngle0 - 0.35,
        (vertices[0].x + vertices[1].x) / 2,
        vertices[0].y,
        -200,
        -600,
        300,
        700
      );
    }
  }

  //Rendering();
});

const camera = new Camera(videoElement, {
  onFrame: async () => {
    await pose.send({ image: videoElement });
  },
  width: 1280,
  height: 720,
  depth: 30,
});

camera.start();
Engine.run(engine);
